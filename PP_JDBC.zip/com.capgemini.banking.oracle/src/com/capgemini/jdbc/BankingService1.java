package com.capgemini.jdbc;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.capgemini.dao.bean.Account;
import com.capgemini.dao.bean.Transaction;
import com.capgemini.dao.exceptions.AccountNotFoundException;

public interface BankingService1 {
	public void insert(Account account);

	public void update(double balance, Integer accountNo);

	public void delete(Integer accountNo) throws AccountNotFoundException;

	// public void showBalance1(Integer accountNo) throws AccountNotFoundException;

	public void addTrans(Transaction transaction, Integer accountNo, Date date);

	public void query();

}
