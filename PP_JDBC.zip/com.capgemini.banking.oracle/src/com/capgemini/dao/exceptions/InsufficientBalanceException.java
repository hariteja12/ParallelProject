package com.capgemini.dao.exceptions;

public class InsufficientBalanceException extends Exception {

	public InsufficientBalanceException(Integer accountNo, String string) {
		super(accountNo + " " + string);
		System.err.println(accountNo + " " + string);
	}

}
