package com.capgemini.dao.exceptions;

import java.util.Scanner;

public class AccountNotFoundException extends Exception {

	public AccountNotFoundException(Integer accountNo, String string) {
		super(accountNo + " " + string);
		Scanner sc = new Scanner(System.in);
		System.err.println(accountNo + " " + string);
		sc.nextLine();

	}

}
