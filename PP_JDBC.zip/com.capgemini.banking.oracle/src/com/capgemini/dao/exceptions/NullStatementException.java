package com.capgemini.dao.exceptions;

public class NullStatementException {

}
