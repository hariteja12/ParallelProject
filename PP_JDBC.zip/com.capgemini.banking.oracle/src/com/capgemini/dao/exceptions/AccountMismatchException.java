package com.capgemini.dao.exceptions;

public class AccountMismatchException extends Exception {

	public AccountMismatchException(Integer accountno1, Integer accountno2, String string) {
		super(accountno1 + " " + accountno2 + " " + string);
		System.err.println(accountno1 + " " + accountno2 + " " + string);
	}

}
