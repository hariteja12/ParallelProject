package com.capgemini.dao.bean;

public class Customer {
	private String name;
	private String city, doorNo, pincode;
	private String phoneNo;

	public Customer() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDoorno() {
		return doorNo;
	}

	public void setDoorno(String doorno) {
		this.doorNo = doorno;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", city=" + city + ", doorno=" + doorNo + ", pincode=" + pincode
				+ ", phoneNo=" + phoneNo + "]";
	}

}
