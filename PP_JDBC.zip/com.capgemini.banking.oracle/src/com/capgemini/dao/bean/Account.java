package com.capgemini.dao.bean;

import java.io.Serializable;
import java.util.ArrayList;

public class Account implements Serializable {

	static Integer ACCNO = 1001;
	ArrayList<Transaction> arrayList;
	private Customer cust;
	private String accountType;
	
	
	public void setAccno(Integer ACCNO) {
		this.ACCNO = ACCNO++;
	}

	private double initialbalance;

	public Account(ArrayList<Transaction> arrayList, Customer cust, String accountType, double initialbalance) {
		super();
		this.arrayList = new ArrayList<Transaction>();
		this.cust = cust;
		this.accountType = accountType;
		this.initialbalance = initialbalance;
	}

	public Account() {
		super();
		setAccno(ACCNO);
		this.arrayList = new ArrayList<Transaction>();
	}

	public void addTransaction(Transaction transaction) {
		this.arrayList.add(transaction);
	}

	public ArrayList<Transaction> getTransaction() {
		return arrayList;
	}

	public void setInitialbalance(double initialbalance) {
		this.initialbalance = initialbalance;
	}

	public double getInitialbalance() {
		return initialbalance;
	}

	public Integer getAccno() {
		return ACCNO++;
	}

	public Customer getCustomer() {
		return cust;
	}

	public void setCustomer(Customer customer) {
		this.cust = customer;
	}

	public String getAccType() {
		return accountType;
	}

	public void setAccType(String accType) {
		this.accountType = accType;
	}

	@Override
	public String toString() {
		return "Account [arrayList=" + arrayList + ", customer=" + cust + ", accType=" + accountType
				+ ", initialbalance=" + initialbalance + "]";
	}

}
