package com.capgemini.dao.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.dao.bean.Account;
import com.capgemini.dao.bean.Customer;
import com.capgemini.dao.exceptions.AccountMismatchException;
import com.capgemini.dao.exceptions.AccountNotFoundException;
import com.capgemini.dao.exceptions.InsufficientBalanceException;
import com.capgemini.dao.exceptions.NullStatementException;
import com.capgemini.jdbc.DaoImpl;
import com.capgemini.services.BankingServiceImpl;

public class BankMain extends Throwable {
	static Scanner sc1 = new Scanner(System.in);

	private static String input(String string) {
		// scan.nextLine();
		String message = string;
		System.out.println(message);
		return sc1.nextLine();
	}

	private static Account createCustomer() {
		Account account = new Account();
		Customer customer = new Customer();
		customer = new Customer();
		sc1.nextLine();
		customer.setName(input("enter name"));
		customer.setPhoneNo(input("enter phone number"));
		customer.setDoorno(input("enter door no"));
		customer.setPincode(input("enter pincode"));
		account.setAccType(input("enter type of account"));
		customer.setCity(input("enter city"));
		account.setCustomer(customer);

		return account;
	}

	public static void main(String[] args) {
		BankingServiceImpl impl = new BankingServiceImpl();
		DaoImpl daoImpl = new DaoImpl();
		String choice = null;
		do {
			System.out.println("welcome to INDIANOVERSEAS Bank");
			System.out.println("1 :Create Account");
			System.out.println("2 :Deposit");
			System.out.println("3 :Funds Transfer");
			System.out.println("4 :Withdraw");
			System.out.println("5 :Query");
			System.out.println("Enter Choice: ");
			choice = sc1.next();
			// scan.nextLine();

			switch (choice) {
			case "1":
				impl.createAccount(createCustomer());
				System.out.println("Account created Successfully");
				break;
			case "2":
				try {
					System.out.println("enter amount to be deposit,enter account no");
					impl.deposit(sc1.nextDouble(), sc1.nextInt());

				} catch (AccountNotFoundException e) {
					System.err.println(e.getMessage());
				} catch (NumberFormatException e) {
					System.err.println("Invalid Input");
				} catch (InputMismatchException e) {
					System.err.println("Input not matched");
				}
				sc1.nextLine();
				break;

			case "3":

				try {
					System.out.println("Enter sender accno and Receiver accNo");
					impl.fundTransfer(sc1.nextInt(), sc1.nextInt());

				} catch (InsufficientBalanceException e1) {

				} catch (AccountMismatchException e) {

				} catch (NumberFormatException e) {
					System.err.println("Invalid Input");
				} catch (InputMismatchException e) {
					System.err.println("Input not matched");
				}

				break;
			case "4":
				try {
					System.out.println("Enter amount and account no to with draw");

					double amount = 0;
					Integer accno = null;
					amount = sc1.nextDouble();
					accno = sc1.nextInt();
					impl.withDraw(amount, accno);

				} catch (InsufficientBalanceException e) {

				} catch (AccountNotFoundException e) {

				} catch (NumberFormatException e) {
					System.err.println("Invalid Input");
				} catch (InputMismatchException e) {
					System.err.println("Input not matched");
				}

				break;

			case "5":
				Integer accno = sc1.nextInt();
				try {

					daoImpl.delete(accno);
					throw new AccountNotFoundException(accno, "Account not found");
				} catch (AccountNotFoundException e) {
				}
				break;
			case "6":

				daoImpl.query();

				break;

			default:
				System.err.println("invalid choice");
			}

		} while (choice.length() != 0);
	}

}
