package com.capgemini.services;

import com.capgemini.dao.bean.*;
import com.capgemini.dao.bean.Account;
import com.capgemini.dao.exceptions.AccountMismatchException;
import com.capgemini.dao.exceptions.AccountNotFoundException;
import com.capgemini.dao.exceptions.InsufficientBalanceException;

public interface BankingService {

	void  createAccount(Account account);

	void deposit(double amount, Integer accountNo) throws AccountNotFoundException;

	void withDraw(double amount, Integer accountNo) throws AccountNotFoundException, InsufficientBalanceException;

	void fundTransfer(Integer accountNo1, Integer accountNo2) throws AccountNotFoundException, InsufficientBalanceException, AccountMismatchException;

	void showBalance(Integer accountNo) throws AccountNotFoundException;

	//void printTransactions(Integer accountNo) throws AccountNotFoundException;
	
}
