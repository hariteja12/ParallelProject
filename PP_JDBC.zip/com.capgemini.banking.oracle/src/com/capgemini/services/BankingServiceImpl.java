package com.capgemini.services;

import java.util.Scanner;

import com.capgemini.dao.bean.Account;
import com.capgemini.dao.bean.Transaction;
import com.capgemini.dao.exceptions.*;
import com.capgemini.jdbc.DaoImpl;

public class BankingServiceImpl implements BankingService {
	static Scanner sc = new Scanner(System.in);
	DaoImpl daoImpl = new DaoImpl();

	@Override
	public void createAccount(Account account) {

		daoImpl.insert(account);

	}

	@Override
	public void deposit(double amount, Integer accountNo) throws AccountNotFoundException {
		double curbal = 0;
		String s = "select accno from Account where accno=" + accountNo;
		Integer accountNo1 = Integer.parseInt(daoImpl.query(s));
		// System.out.println(accNo1);
		if (accountNo1.equals(accountNo)) {
			String s1 = "select initialbalance from Account where accno=" + accountNo;
			double initial = Integer.parseInt(daoImpl.query(s1));
			curbal += initial + amount;
			daoImpl.update(curbal, accountNo);
			System.out.println("deposit done successfully");
			Transaction transaction = new Transaction("CR", "Deposited", amount);

			java.sql.Date date = getCurrentDate();
			daoImpl.addTrans(transaction, accountNo, date);

		} else {

			try {
				throw new AccountNotFoundException(accountNo, "account not found");
			} catch (AccountNotFoundException e) {

			}

		}

	}

	public java.sql.Date getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Date(today.getTime());
	}

	@Override
	public void withDraw(double amount, Integer accountNo) throws AccountNotFoundException, InsufficientBalanceException {
		double curbal = 0;
		String s = "select accno from Account where accno=" + accountNo;
		Integer accountNo1 = Integer.parseInt(daoImpl.query(s));
		if (accountNo1.equals(accountNo)) {

			String s1 = "select initialbalance from Account where accno=" + accountNo;
			double initial = Integer.parseInt(daoImpl.query(s1));

			if (initial >= amount) {
				curbal += initial - amount;
				daoImpl.update(curbal, accountNo);

				System.out.println("withdrawl is done");
				Transaction transaction = new Transaction("DR", "Debited", amount);

				java.sql.Date date = getCurrentDate();
				daoImpl.addTrans(transaction, accountNo, date);

			} else {

				throw new InsufficientBalanceException(accountNo, " has Insufficient balance");
			}
		} else {

			throw new AccountNotFoundException(accountNo, "account not found");
		}
	}

	@Override
	public void fundTransfer(Integer accountNo1, Integer accountNo2)
			throws InsufficientBalanceException, AccountMismatchException {
		double senderInitial = 0, receiveamt = 0, amount = 0;
		if (accountNo1.equals(accountNo2))
			throw new AccountMismatchException(accountNo1, accountNo2, "are same");
		else {
			String s = "select initialbalance from Account where accno=" + accountNo1;
			double initial = Integer.parseInt(daoImpl.query(s));
			String s2 = "select initialbalance from Account where accno=" + accountNo2;
			double initial2 = Integer.parseInt(daoImpl.query(s2));
			System.out.println("Enter amount to be transfered");
			amount = sc.nextDouble();
			if (amount > initial) {
				throw new InsufficientBalanceException(accountNo1, "Amount greater than bankbalance");
			} else {
				receiveamt = initial2 + amount;
				senderInitial = initial - amount;

				System.out.println("funds transfered");

				daoImpl.update(senderInitial, accountNo1);
				daoImpl.update(receiveamt, accountNo2);
				Transaction transaction1 = new Transaction("DR", "Deposited", amount);

				java.sql.Date date = getCurrentDate();
				daoImpl.addTrans(transaction1, accountNo1, date);
				Transaction transaction = new Transaction("CR", "Deposited", amount);

				java.sql.Date date2 = getCurrentDate();
				daoImpl.addTrans(transaction, accountNo2, date2);
			}
		}
	}

	@Override
	public void showBalance(Integer accountNo) throws AccountNotFoundException {
		String query = "select initialbalance from Account where accno=" + accountNo;
		double balance = Double.parseDouble(daoImpl.query(query));
		System.out.println(balance);

	}

}
