package com.parallel.spring.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.parallel.spring.beans.Account;

@Repository
public interface AccountDao extends JpaRepository<Account, Integer> {

}
