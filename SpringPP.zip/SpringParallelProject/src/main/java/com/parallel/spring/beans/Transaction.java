package com.parallel.spring.beans;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "spring2", initialValue = 10001, allocationSize = 1)
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "spring2")
	private Integer trans_Id;
	private String type;
	private String description;
	private double amount;
	private Date date1;
	@ManyToOne(cascade = CascadeType.ALL)
	private Account account;

	public Transaction() {
		super();
	}

	public Transaction(String type, String description, double amount) {
		super();
		this.type = type;
		this.description = description;
		this.amount = amount;
	}

	public int getAccount() {
		return account.getAccno();
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getDate1() {
		return date1;
	}

	public void setDate1(Date date1) {
		this.date1 = date1;
	}

	public Integer getTrans_Id() {
		return trans_Id;
	}

}
