package com.parallel.spring.service;

import java.util.List;

import com.parallel.spring.beans.Account;
import com.parallel.spring.beans.Transaction;
import com.parallel.spring.exceptions.AccountMismatchException;
import com.parallel.spring.exceptions.AccountNotFound;
import com.parallel.spring.exceptions.InvalidAmountException;

public interface BankService {

	List<Account> createAcccount(Account account);

	List<Account> getAllAccounts();

	

	List<Account> deposit(int accno, double amount) throws InvalidAmountException, AccountNotFound;

	List<Account> withdraw(int accno, double amount) throws InvalidAmountException, AccountNotFound;

	List<Account> fundsTransfer(int accno1, int accno2, double amount) throws AccountMismatchException, InvalidAmountException, AccountNotFound;

	List<Transaction> getAllTransactions();

	double getInitialBalance(int accno) throws AccountNotFound;

	List<Transaction> getTransactionByAccno(int accno);

	Account getAccountByNo(int accno) throws AccountNotFound;

	
}
