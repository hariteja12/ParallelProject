package com.cg.banking.UI;

import java.util.Scanner;

import com.cg.banking.bean.Account;
import com.cg.banking.bean.Customer;
import com.cg.banking.bean.Transaction;
import com.cg.banking.service.*;

public class Banking_Main {
	static Scanner s = new Scanner(System.in);
	private static String input(String string) {
		String input=string;
		System.out.println(input);
		return s.nextLine();
	}
	
	 static Account customerDetails(){
		 Account account=new Account();
			Customer customer=new Customer();
			s.nextLine();
			customer.setName(input("Enter Name"));
			customer.setPhoneNo(input("Enter Phone number"));
			customer.setEmailId(input("Enter EmailId"));
			customer.setDoorNo(input("Enter DrNo"));
			customer.setCity(input("Enter City"));
			customer.setPinCode(input("Enter ZipCode"));
			customer.setCountry(input("Enter Country"));
			account.setAccountType(input("Enter the Account Type"));
			account.setCustomer(customer);
			return account;
		 
	 }
	public static void main(String[] args) {

		BankingServiceImpl impl=new BankingServiceImpl();
		
		int choice = 0;

		do {
			System.out.println("\n");
			System.out.println("welcome to IndianOverseas bank...");
			System.out.println("1.Create Account");
			System.out.println("2.Checkbalance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			System.out.println("Enter Choice: ");
			choice = s.nextInt();

			switch (choice) {
			case 1:
				
				impl.createAccount(customerDetails());
				System.out.println("Account is successfully created");
				break;
			case 2:
				System.out.println("Enter the Account Number");
				System.out.println("Account balance: "+impl.showBalance(s.nextInt()));
				break;
			case 3:
				System.out.println("Enter the Amount to be deposited and Account Number ");
				impl.deposit(s.nextInt(), s.nextInt());
				s.nextLine();
				System.out.println("Amount is deposited");
				break;

			case 4:
				System.out.println("Enter the amount to be Withdraw and Account Number ");
				impl.withdraw(s.nextInt(), s.nextInt());
				s.nextLine();
				System.out.println("Amount is Withdrawn");
				break;
			case 5:
				System.out.println("Enter the sender and reciever account numbers");
				impl.fundtransfer(s.nextInt(), s.nextInt());
				System.out.println("Amount is Transfer");
				break;
			case 6:
				System.out.println("Enter the Account Number");
				impl.transactionList(s.nextInt());
				break;
			case 7:
				System.out.println("Thank you");
				break;
			default:
				System.out.println("Enter valid option");
				break;

			}
		} while (choice != 7);
	}
}
