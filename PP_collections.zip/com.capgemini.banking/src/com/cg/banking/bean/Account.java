package com.cg.banking.bean;

import java.util.ArrayList;

public class Account {
	static Integer accountNo = 12345001;
	private String account1Type;
	private double balance;
	private Customer customer;

	private ArrayList<Transaction> transaction;

	public void addTransaction(Transaction transaction) {
		this.transaction.add(transaction);
	}

	public Account() {
		super();
		this.transaction = new ArrayList<Transaction>();
	}

	public Account(String accountType, double balance, Customer customer, ArrayList<Transaction> transaction) {
		super();
		this.account1Type = accountType;
		this.balance = balance;
		this.customer = customer;
		this.transaction = transaction;
	}

	public ArrayList<Transaction> getTransaction() {
		return transaction;
	}

	public void setTransaction(ArrayList<Transaction> transaction) {
		this.transaction = transaction;
	}

	public Integer getAccountNo() {
		return accountNo++;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getAccountType() {
		return account1Type;
	}

	public void setAccountType(String accountType) {
		this.account1Type = accountType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double currentBalance) {
		this.balance = currentBalance;
	}

	@Override
	public String toString() {
		return "Account [accountType=" + account1Type + ", balance=" + balance + ", customer=" + customer + "]";
	}

}
