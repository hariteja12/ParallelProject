package com.cg.banking.bean;

public class Transaction {
	static Integer initialTransactionId=1000233;
	private Integer transactId;
	private String transactType;
	private double transactAmount;
	
	public Transaction(String transactionType, double transactionAmount) {
		super();
		this.setTransactionId();
		this.transactType = transactionType;
		this.transactAmount = transactionAmount;
	}
	public Transaction() {
		super();
		this.setTransactionId();
	}
	public void setTransactionId() {
		this.transactId = initialTransactionId++;
	}

	public Integer getTransactionId() {
		return transactId;
	}
	public String getTransactionType() {
		return transactType;
	}
	public void setTransactionType(String transactionType) {
		this.transactType = transactionType;
	}
	public double getTransactionAmount() {
		return transactAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactAmount = transactionAmount;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactId + ", transactionType=" + transactType
				+ ", transactionAmount=" + transactAmount + "]";
	}
	
	
}
