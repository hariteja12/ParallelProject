package com.cg.banking.bean;

public class Customer {
	private String name;
	private String emailId;
	private String phNo;
	private String drNo;
	private String city;
	private String pinCode;
	private String country;
	public String getPhoneNo() {
		return phNo;
	}
	public void setPhoneNo(String string) {
		this.phNo = string;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public String getDoorNo() {
		return drNo;
	}
	public void setDoorNo(String doorNo) {
		this.drNo = doorNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", emailId=" + emailId + ", phoneNo=" + phNo + ", doorNo=" + drNo
				+ ", city=" + city + ", pinCode=" + pinCode + ", country=" + country + "]";
	}
	
	
	
}