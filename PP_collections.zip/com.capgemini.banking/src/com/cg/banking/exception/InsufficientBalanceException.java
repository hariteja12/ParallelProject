package com.cg.banking.exception;

public class InsufficientBalanceException extends Exception {
	public InsufficientBalanceException(Integer accouNo,String st){
		super(accouNo+" "+st);
		System.err.println(accouNo+" "+st);
	}

}
