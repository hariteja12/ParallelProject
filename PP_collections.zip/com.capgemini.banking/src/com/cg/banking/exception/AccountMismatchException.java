package com.cg.banking.exception;

import java.util.Scanner;

public class AccountMismatchException extends Exception{
	private String accouNo1;

	public AccountMismatchException(Integer accouNo1,Integer accouNo2,String st){
		super(accouNo1+","+accouNo2+" "+st);
		System.err.println(accouNo1+","+accouNo2+" "+st);
	}

}
