package com.cg.banking.exception;

import java.util.Scanner;

public class AccountNotFoundException extends Exception {
		public AccountNotFoundException(Integer accouNo,String st){
			super(accouNo+" "+st);
			Scanner sc=new Scanner(System.in);
			System.err.println(accouNo+" "+st);
			sc.nextLine();
		}

}
