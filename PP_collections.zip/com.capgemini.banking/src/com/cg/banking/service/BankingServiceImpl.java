package com.cg.banking.service;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.cg.banking.bean.Account;
import com.cg.banking.bean.Customer;
import com.cg.banking.bean.Transaction;
import com.cg.banking.exception.AccountNotFoundException;

public class BankingServiceImpl implements Bankingservice {

	Account account = new Account();
	Customer customer = new Customer();
	double currentBalance;

	HashMap<Integer, Account> account1 = new HashMap<Integer, Account>();

	@Override
	public void createAccount(Account account) {
		account1.put(account.getAccountNo(), account);
		System.out.println(account1);
	}

	@Override
	public void deposit(Integer amount, Integer accouNo) {
		if (account1.containsKey(accouNo)) {
			currentBalance = account1.get(accouNo).getBalance() + amount;
			account1.get(accouNo).setBalance(currentBalance);
			Transaction transaction = new Transaction("Credit", amount);
			account1.get(accouNo).addTransaction(transaction);
		} else {
			System.out.println("Account not found");
		}
	}

	@Override
	public void withdraw(Integer amount, Integer accouNo) {
		if (account1.containsKey(accouNo)) {
			currentBalance = account1.get(accouNo).getBalance() - amount;
			account1.get(accouNo).setBalance(currentBalance);
			Transaction transaction = new Transaction("Debit", amount);
			account1.get(accouNo).addTransaction(transaction);
		} else {
			System.out.println(" Insufficient Balance ");
		}
	}

	@Override
	public double showBalance(Integer accouNo) {

		return account1.get(accouNo).getBalance();

	}

	Scanner s = new Scanner(System.in);

	@Override
	public void fundtransfer(Integer accouNo1, Integer accouNo2) {
		if (accouNo1 != accouNo2) {
			double sent, recieved, amount;
			sent = account1.get(accouNo1).getBalance();
			recieved = account1.get(accouNo2).getBalance();
			System.out.println("Enter the amount to be transfered");
			amount = s.nextFloat();
			if (sent < amount) {
				System.out.println(" Enter the amount with in limit");
			} else {
				sent = account1.get(accouNo1).getBalance() - amount;
				recieved = account1.get(accouNo2).getBalance() + amount;
				account1.get(accouNo1).setBalance(sent);
				account1.get(accouNo2).setBalance(recieved);
				Transaction transaction = new Transaction("Debit", amount);
				account1.get(accouNo1).addTransaction(transaction);
				Transaction transaction1 = new Transaction("Credit", amount);
				account1.get(accouNo2).addTransaction(transaction1);
			}

		}
	}

	@Override
	public void transactionList(Integer accouNo) {
		if (account1.containsKey(accouNo)) {
			List<Transaction> transaction = account1.get(accouNo).getTransaction();
			transaction.forEach(System.out::println);
		} else {
			try {
				throw new AccountNotFoundException(accouNo, "Account not found");
			} catch (AccountNotFoundException e) {
				e.printStackTrace();
			}
		}
	}
}
