package com.cg.banking.service;

import com.cg.banking.bean.Account;

public interface Bankingservice {
	public void createAccount(Account account);
	public void deposit(Integer amount,Integer accouNo);
	public void withdraw(Integer amount,Integer accouNo);
	public double showBalance(Integer accouNo);
	public void fundtransfer(Integer accouNo1,Integer accouNo2);
	public void transactionList(Integer accouNo);
	
}
