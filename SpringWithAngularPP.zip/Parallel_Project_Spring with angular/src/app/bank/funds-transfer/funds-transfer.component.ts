import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-funds-transfer',
  templateUrl: './funds-transfer.component.html',
  styleUrls: ['./funds-transfer.component.css']
})
export class FundsTransferComponent implements OnInit {

  accounts:Account[];
  constructor(private bankService:BankService,private router:Router) { }
  
  ngOnInit() {
  }
  transfer(value)
  {
    this.bankService.transfer(value).subscribe(data=>{this.accounts=data});
  this.router.navigate(["/show"]);
}
}
