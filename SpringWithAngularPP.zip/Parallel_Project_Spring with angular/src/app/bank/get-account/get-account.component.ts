import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';


@Component({
  selector: 'app-get-account',
  templateUrl: './get-account.component.html',
  styleUrls: ['./get-account.component.css']
})
export class GetAccountComponent implements OnInit {
account:Account;
  constructor(private bankService:BankService) { }

  ngOnInit() {
  }
  get(value) {
  
    this.bankService.getDetails(value).subscribe(data => {
      this.account = data;
    });
    console.log(this.account);
  }
}
