import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
account:Account;
  constructor(private bankService:BankService,private router:Router) { }

  ngOnInit() {
  }
deposit(value)
{
 
  this.bankService.deposit(value).subscribe(data => {
this.account = data;
  });
  console.log(this.account);
  this.router.navigate(["/show"]);
};
}

