export interface Account {
    accno: number;
    initialbalance: number;
    accType: String;
    name: String;
    mobile: String;
    dno: String;
    city: String;
    pincode: String;
}