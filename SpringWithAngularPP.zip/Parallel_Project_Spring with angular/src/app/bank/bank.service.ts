import { Injectable } from '@angular/core';
import { Transaction } from './Transaction';
import { HttpClient, HttpParams } from '@angular/common/http';
import {Account} from './Account';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  accounts: Account[];
  transactions: Transaction[];
  account: Account;
  constructor(private http: HttpClient) {
    
  }
  populateAccounts(): Observable<Account[]> {
    return this.http.get<Account[]>("http://localhost:4002/accounts");
    
  }
  getAccounts(): Account[]{
    return this.accounts;
  }
  addAccount(account: Account) {
    return this.http.post<Account>("http://localhost:4002/create", account).toPromise().then(data => console.log(data));
    
  }
  getDetails(value): any {
    return this.http.get("http://localhost:4002/get1/" + value.accno);
  }
  deposit(value): any {
    console.log(value.accno,value.amount);
    
    return this.http.get("http://localhost:4002/accounts/deposit/"+value.accno+"/"+value.amount);
  }
  getTransactions(): any {
    return this.http.get("http://localhost:4002/transactions");
  }
  getTrans(value): any {
   return this.http.get("http://localhost:4002/get/"+value.accno);
  }
  withdraw(value): any {
    return this.http.get("http://localhost:4002/accounts/withdraw/"+value.accno+"/"+value.amount);
  }
  transfer(value): any {
    return this.http.get("http://localhost:4002/accounts/transfer/"+value.accno1+"/"+value.accno2+"/"+value.amount);
  }
}
