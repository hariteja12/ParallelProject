import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Transaction } from '../Transaction';

@Component({
  selector: 'app-transaction-list',
  templateUrl: './transaction-list.component.html',
  styleUrls: ['./transaction-list.component.css']
})
export class TransactionListComponent implements OnInit {
transactions:Transaction[];
constructor(private bankService:BankService) { 
// this.bankService.getTransactions().subscribe(data => this.transactions = data, error => console.log(error));

}

  ngOnInit() {
   
  }
getTrans(value)
{
  this.bankService.getTrans(value).subscribe(data => this.transactions = data, error => console.log(error));
}
}
